
"use client";

import { useEffect, useRef, useState, type ChangeEvent, type DragEvent } from "react";
import {
    UploadCloud,
    Image as ImageIcon,
    Download,
    Grid3X3,
    RotateCcw,
    
    AlertCircle,
    CheckCircle2,
    Loader2,
    Archive,
} from "lucide-react";

const MAX_FILE_SIZE = 12 * 1024 * 1024;
const MAX_PIXELS = 40_000_000;
const MAX_TILES = 100;

type TileResult = {
    name: string;
    blob: Blob;
    url: string;
    width: number;
    height: number;
    row: number;
    column: number;
};

function downloadBlob(blob: Blob, filename: string) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();

    window.setTimeout(() => URL.revokeObjectURL(url), 1500);
}

function UploadIcon() {
    return (
        <UploadCloud className="h-8 w-8" aria-hidden="true" />
    );
}

export function ImageSplitterWorkspace() {
    const inputRef = useRef<HTMLInputElement>(null);
    const originalUrlRef = useRef<string | null>(null);
    const tileUrlsRef = useRef<string[]>([]);

    const [file, setFile] = useState<File | null>(null);
    const [previewUrl, setPreviewUrl] = useState("");
    const [rows, setRows] = useState(3);
    const [columns, setColumns] = useState(3);
    const [tiles, setTiles] = useState<TileResult[]>([]);
    const [processing, setProcessing] = useState(false);
    const [packing, setPacking] = useState(false);
    const [progress, setProgress] = useState(0);
    const [error, setError] = useState("");
    const [message, setMessage] = useState("");
    const [dragging, setDragging] = useState(false);
    const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

    useEffect(() => {
        return () => {
            if (originalUrlRef.current) {
                URL.revokeObjectURL(originalUrlRef.current);
            }

            tileUrlsRef.current.forEach((url) => URL.revokeObjectURL(url));
        };
    }, []);

    function clearTiles() {
        tileUrlsRef.current.forEach((url) => URL.revokeObjectURL(url));
        tileUrlsRef.current = [];
        setTiles([]);
    }

    function chooseFile(selected?: File) {
        if (!selected || processing) return;

        setError("");
        setMessage("");
        clearTiles();

        if (!selected.type.startsWith("image/")) {
            setError("Please choose a valid image file.");
            return;
        }

        if (selected.size > MAX_FILE_SIZE) {
            setError("This image is larger than 12 MB. Choose a smaller image.");
            return;
        }

        if (originalUrlRef.current) {
            URL.revokeObjectURL(originalUrlRef.current);
        }

        const url = URL.createObjectURL(selected);
        originalUrlRef.current = url;

        setFile(selected);
        setPreviewUrl(url);
        setDimensions({ width: 0, height: 0 });
        setMessage("Image uploaded successfully. Choose your tile layout.");

        createImageBitmap(selected)
            .then((bitmap) => {
                setDimensions({
                    width: bitmap.width,
                    height: bitmap.height,
                });
                bitmap.close();
            })
            .catch(() => {
                setError("This image could not be opened. Try another image format.");
            });
    }

    function handleInput(event: ChangeEvent<HTMLInputElement>) {
        chooseFile(event.target.files?.[0]);
        event.target.value = "";
    }

    function handleDrop(event: DragEvent<HTMLDivElement>) {
        event.preventDefault();
        setDragging(false);
        chooseFile(event.dataTransfer.files?.[0]);
    }

    async function splitImage() {
        if (!file || processing || packing) return;

        const tileCount = rows * columns;

        if (
            !Number.isInteger(rows) ||
            !Number.isInteger(columns) ||
            rows < 1 ||
            columns < 1 ||
            tileCount > MAX_TILES
        ) {
            setError(`Choose a layout containing between 1 and ${MAX_TILES} tiles.`);
            return;
        }

        setProcessing(true);
        setProgress(0);
        setError("");
        setMessage("");
        clearTiles();

        let bitmap: ImageBitmap | null = null;

        try {
            bitmap = await createImageBitmap(file);

            if (bitmap.width * bitmap.height > MAX_PIXELS) {
                throw new Error("This image exceeds the 40-megapixel processing limit.");
            }

            if (rows > bitmap.height || columns > bitmap.width) {
                throw new Error(
                    "The selected grid is too large for this image's pixel dimensions."
                );
            }

            const generated: TileResult[] = [];

            const baseName =
                file.name.replace(/\.[^.]+$/, "") || "brobex-image";

            for (let row = 0; row < rows; row++) {
                for (let column = 0; column < columns; column++) {
                    const left = Math.floor((column * bitmap.width) / columns);
                    const top = Math.floor((row * bitmap.height) / rows);
                    const right = Math.floor(((column + 1) * bitmap.width) / columns);
                    const bottom = Math.floor(((row + 1) * bitmap.height) / rows);

                    const tileWidth = right - left;
                    const tileHeight = bottom - top;

                    const canvas = document.createElement("canvas");
                    canvas.width = tileWidth;
                    canvas.height = tileHeight;

                    const context = canvas.getContext("2d");

                    if (!context) {
                        throw new Error("Your browser could not create an image canvas.");
                    }

                    context.drawImage(
                        bitmap,
                        left,
                        top,
                        tileWidth,
                        tileHeight,
                        0,
                        0,
                        tileWidth,
                        tileHeight
                    );

                    const blob = await new Promise<Blob>((resolve, reject) => {
                        canvas.toBlob(
                            (result) => {
                                if (result) resolve(result);
                                else reject(new Error("A tile could not be exported."));
                            },
                            "image/png"
                        );
                    });

                    const name = `${baseName}-row-${row + 1}-column-${column + 1}.png`;
                    const url = URL.createObjectURL(blob);

                    generated.push({
                        name,
                        blob,
                        url,
                        width: tileWidth,
                        height: tileHeight,
                        row: row + 1,
                        column: column + 1,
                    });

                    canvas.width = 0;
                    canvas.height = 0;

                    setProgress(Math.round((generated.length / tileCount) * 100));
                }
            }

            tileUrlsRef.current = generated.map((tile) => tile.url);
            setTiles(generated);
            setMessage(
                `Successfully split your image into ${generated.length} PNG tiles.`
            );
        } catch (cause) {
            generatedCleanup(tileUrlsRef.current);
            tileUrlsRef.current = [];

            setError(
                cause instanceof Error
                    ? cause.message
                    : "Image splitting failed. Please try another image."
            );
        } finally {
            bitmap?.close();
            setProcessing(false);
            setProgress(0);
        }
    }

    function generatedCleanup(urls: string[]) {
        urls.forEach((url) => URL.revokeObjectURL(url));
    }

    async function downloadAll() {
        if (!tiles.length || packing) return;

        setPacking(true);
        setError("");

        try {
            const JSZip = (await import("jszip")).default;
            const zip = new JSZip();

            tiles.forEach((tile) => {
                zip.file(tile.name, tile.blob);
            });

            const archive = await zip.generateAsync({
                type: "blob",
                compression: "DEFLATE",
                compressionOptions: { level: 5 },
            });

            const baseName =
                file?.name.replace(/\.[^.]+$/, "") || "brobex-image";

            downloadBlob(archive, `${baseName}-split-tiles.zip`);
            setMessage("Your ZIP archive is ready.");
        } catch {
            setError("ZIP export failed. You can still download individual tiles.");
        } finally {
            setPacking(false);
        }
    }

    function reset() {
        if (processing || packing) return;

        clearTiles();

        if (originalUrlRef.current) {
            URL.revokeObjectURL(originalUrlRef.current);
            originalUrlRef.current = null;
        }

        setFile(null);
        setPreviewUrl("");
        setDimensions({ width: 0, height: 0 });
        setError("");
        setMessage("");

        if (inputRef.current) {
            inputRef.current.value = "";
        }
    }

    const tileCount = rows * columns;
    const busy = processing || packing;

    return (
        <main className="image-splitter-workspace">
            <div className="image-splitter-shell">
                <section className={`image-splitter-card${file ? " has-image" : ""}`}>
                    {!file ? (
                        <div
                            onDragOver={(event) => {
                                event.preventDefault();
                                setDragging(true);
                            }}
                            onDragLeave={() => setDragging(false)}
                            onDrop={handleDrop}
                            className={`image-splitter-dropzone flex min-h-[310px] flex-col items-center justify-center rounded-2xl border border-dashed px-5 py-12 text-center transition sm:min-h-[360px] ${dragging
                                    ? "border-white bg-white/10"
                                    : "border-white/20 bg-white/[0.02]"
                                }`}
                        >
                            <div className="image-splitter-upload-icon mb-5 flex h-16 w-16 items-center justify-center rounded-2xl border border-white/25 bg-white/10 text-white">
                                <UploadIcon />
                            </div>

                            <h2 className="image-splitter-upload-title text-xl font-semibold tracking-tight">
                                Drop your image here
                            </h2>

                            <p className="image-splitter-upload-description mt-2 max-w-sm text-sm leading-6 text-white/50">
                                Upload an image from your device to create a custom tile grid.
                            </p>

                            <button
                                type="button"
                                onClick={() => inputRef.current?.click()}
                                className="image-splitter-upload-button mt-7 inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-semibold transition focus:outline-none"
                            >
                                <UploadIcon />
                                Choose Image
                            </button>

                            <p className="image-splitter-file-note mt-4 text-xs text-white/35">
                                JPG · PNG · WEBP · Up to 12 MB
                            </p>
                        </div>
                    ) : (
                        <>
                            <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
                                <div className="min-w-0">
                                    <p className="text-sm font-semibold text-white">
                                        Image workspace
                                    </p>
                                    <p className="mt-1 break-all text-xs text-white/45">
                                        {file.name}
                                        {dimensions.width > 0 &&
                                            ` · ${dimensions.width} × ${dimensions.height}px`}
                                    </p>
                                </div>

                                <button
                                    type="button"
                                    onClick={reset}
                                    disabled={busy}
                                    className="rounded-lg border border-white/10 px-3 py-2 text-xs text-white/65 transition hover:border-white/25 hover:text-white disabled:opacity-40"
                                >
                                    <span className="inline-flex items-center gap-2">
                                        <RotateCcw size={14} /> Change image
                                    </span>
                                </button>
                            </div>

                            <div className="grid gap-4 md:grid-cols-2">
                                <div className="overflow-hidden rounded-2xl border border-white/10 bg-[#090b0b]">
                                    <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
                                        <span className="text-xs font-medium text-white/70">
                                            Original image
                                        </span>
                                        <ImageIcon size={15} className="text-white/40" />
                                    </div>

                                    <div className="flex min-h-[250px] items-center justify-center p-4 sm:min-h-[340px]">
                                        <img
                                            src={previewUrl}
                                            alt="Original image"
                                            className="max-h-[420px] max-w-full rounded-lg object-contain"
                                        />
                                    </div>
                                </div>

                                <div className="overflow-hidden rounded-2xl border border-white/10 bg-[#090b0b]">
                                    <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
                                        <span className="text-xs font-medium text-white/70">
                                            Live grid preview
                                        </span>
                                        <span className="rounded-md bg-white/10 px-2 py-1 text-[10px] text-white">
                                            {rows} × {columns}
                                        </span>
                                    </div>

                                    <div className="flex min-h-[250px] items-center justify-center p-4 sm:min-h-[340px]">
                                        <div className="relative w-full overflow-hidden rounded-lg">
                                            <img
                                                src={previewUrl}
                                                alt="Image with tile grid preview"
                                                className="block max-h-[420px] w-full object-contain"
                                            />
                                            <div
                                                className="pointer-events-none absolute inset-0 grid"
                                                style={{
                                                    gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))`,
                                                    gridTemplateRows: `repeat(${rows}, minmax(0, 1fr))`,
                                                }}
                                            >
                                                {Array.from({ length: tileCount }).map((_, index) => (
                                                    <div
                                                        key={index}
                                                        className="border border-white/90 bg-white/[0.06]"
                                                    />
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <section className="mt-6 rounded-2xl border border-white/10 bg-white/[0.025] p-4 sm:p-5">
                                <div className="flex flex-wrap items-center justify-between gap-3">
                                    <div>
                                        <h3 className="text-sm font-semibold text-white">
                                            Grid configuration
                                        </h3>
                                        <p className="mt-1 text-xs text-white/45">
                                            Customize the number of rows and columns.
                                        </p>
                                    </div>

                                    <span className="rounded-lg border border-white/10 bg-[#171a1a] px-3 py-2 text-xs text-white/70">
                                        {tileCount} tiles
                                    </span>
                                </div>

                                <div className="mt-5 grid gap-4 sm:grid-cols-2">
                                    <label className="flex flex-col gap-2 text-xs text-white/60">
                                        Rows
                                        <input
                                            type="number"
                                            min={1}
                                            max={100}
                                            value={rows}
                                            disabled={busy}
                                            onChange={(event) =>
                                                setRows(Math.max(1, Math.min(100, Number(event.target.value) || 1)))
                                            }
                                            className="min-h-11 rounded-xl border border-white/15 bg-[#171a1a] px-3 text-sm text-white outline-none focus:border-white disabled:opacity-50"
                                        />
                                    </label>

                                    <label className="flex flex-col gap-2 text-xs text-white/60">
                                        Columns
                                        <input
                                            type="number"
                                            min={1}
                                            max={100}
                                            value={columns}
                                            disabled={busy}
                                            onChange={(event) =>
                                                setColumns(Math.max(1, Math.min(100, Number(event.target.value) || 1)))
                                            }
                                            className="min-h-11 rounded-xl border border-white/15 bg-[#171a1a] px-3 text-sm text-white outline-none focus:border-white disabled:opacity-50"
                                        />
                                    </label>
                                </div>

                                <div className="mt-4 flex flex-wrap gap-2">
                                    {[2, 3, 4].map((size) => (
                                        <button
                                            key={size}
                                            type="button"
                                            disabled={busy || size * size > MAX_TILES}
                                            onClick={() => {
                                                setRows(size);
                                                setColumns(size);
                                                clearTiles();
                                                setMessage("");
                                            }}
                                            className="rounded-lg border border-white/10 px-3 py-2 text-xs text-white/65 transition hover:border-white/60 hover:text-white disabled:opacity-40"
                                        >
                                            {size} × {size}
                                        </button>
                                    ))}
                                </div>

                                {tileCount > MAX_TILES && (
                                    <p className="mt-3 text-xs text-amber-200">
                                        Maximum supported layout: {MAX_TILES} tiles.
                                    </p>
                                )}

                                <button
                                    type="button"
                                    onClick={splitImage}
                                    disabled={busy || tileCount > MAX_TILES || dimensions.width === 0}
                                    className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-black px-5 py-3.5 text-sm font-semibold text-white transition hover:bg-[#1a1a1a] focus:outline-none focus:ring-2 focus:ring-black focus:ring-offset-2 disabled:cursor-wait disabled:opacity-60 sm:w-auto"
                                >
                                    {processing ? (
                                        <>
                                            <Loader2 className="h-5 w-5 animate-spin" />
                                            Splitting {progress}%
                                        </>
                                    ) : (
                                        <>
                                            <Grid3X3 size={17} />
                                            Split Image
                                        </>
                                    )}
                                </button>

                                {processing && (
                                    <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/10">
                                        <div
                                            className="h-full rounded-full bg-gradient-to-r from-[#a95835] via-[#000000] to-[#000000] transition-[width] duration-300"
                                            style={{ width: `${progress}%` }}
                                        />
                                    </div>
                                )}
                            </section>
                        </>
                    )}

                    <input
                        ref={inputRef}
                        type="file"
                        accept="image/*"
                        className="sr-only"
                        onChange={handleInput}
                    />

                    {error && (
                        <div className="mt-5 flex items-start gap-3 rounded-xl border border-red-400/20 bg-red-400/[0.07] px-4 py-3 text-sm leading-6 text-red-200">
                            <AlertCircle size={18} className="mt-0.5 shrink-0" />
                            <div>
                                <p className="font-medium">Unable to process image</p>
                                <p className="mt-1 text-red-100/75">{error}</p>
                            </div>
                        </div>
                    )}

                    {message && !error && (
                        <div className="mt-5 flex items-start gap-2 rounded-xl border border-emerald-400/20 bg-emerald-400/[0.07] px-4 py-3 text-sm text-emerald-200">
                            <CheckCircle2 size={17} className="shrink-0" />
                            {message}
                        </div>
                    )}

                    {tiles.length > 0 && (
                        <section className="mt-7">
                            <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
                                <div>
                                    <h3 className="text-lg font-semibold">Your image tiles</h3>
                                    <p className="mt-1 text-xs text-white/45">
                                        {tiles.length} PNG files · Original image dimensions preserved
                                    </p>
                                </div>

                                <button
                                    type="button"
                                    onClick={downloadAll}
                                    disabled={packing}
                                    className="inline-flex items-center justify-center gap-2 rounded-xl bg-white px-4 py-3 text-xs font-semibold text-black transition hover:bg-neutral-200 disabled:opacity-60"
                                >
                                    {packing ? (
                                        <Loader2 size={16} className="animate-spin" />
                                    ) : (
                                        <Archive size={16} />
                                    )}
                                    {packing ? "Creating ZIP..." : "Download All ZIP"}
                                </button>
                            </div>

                            <div className="space-y-7">

                                {/* Reconstructed original image */}
                                <div>
                                    <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                                        <div>
                                            <h4 className="text-sm font-semibold text-white">
                                                Reconstructed image
                                            </h4>
                                            <p className="mt-1 text-xs text-white/45">
                                                All split pieces arranged in their original positions.
                                            </p>
                                        </div>

                                        <span className="rounded-lg border border-emerald-400/20 bg-emerald-400/[0.07] px-3 py-2 text-xs text-emerald-300">
                                            {rows} Rows × {columns} Columns
                                        </span>
                                    </div>

                                    <div
                                        className="mx-auto w-full max-w-3xl overflow-hidden rounded-xl border border-white/15 bg-[#090b0b]"
                                        style={{
                                            aspectRatio: `${dimensions.width} / ${dimensions.height}`,
                                        }}
                                    >
                                        <div
                                            className="grid h-full w-full gap-0"
                                            style={{
                                                gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))`,
                                                gridTemplateRows: `repeat(${rows}, minmax(0, 1fr))`,
                                            }}
                                        >
                                            {tiles
                                                .slice()
                                                .sort((a, b) => a.row - b.row || a.column - b.column)
                                                .map((tile) => (
                                                    <div
                                                        key={tile.name}
                                                        className="relative min-h-0 min-w-0 overflow-hidden border-[0.5px] border-[#000000]/50"
                                                    >
                                                        <img
                                                            src={tile.url}
                                                            alt={`Row ${tile.row}, column ${tile.column}`}
                                                            className="block h-full w-full object-fill"
                                                        />

                                                        <span className="absolute bottom-1 left-1 rounded bg-black/75 px-1.5 py-1 text-[9px] text-white">
                                                            {tile.row}:{tile.column}
                                                        </span>
                                                    </div>
                                                ))}
                                        </div>
                                    </div>
                                </div>

                                {/* Individual downloadable tiles */}
                                <div>
                                    <div className="mb-4">
                                        <h4 className="text-sm font-semibold text-white">
                                            Individual image tiles
                                        </h4>
                                        <p className="mt-1 text-xs text-white/45">
                                            Download any split section separately.
                                        </p>
                                    </div>

                                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
                                        {tiles
                                            .slice()
                                            .sort((a, b) => a.row - b.row || a.column - b.column)
                                            .map((tile) => (
                                                <article
                                                    key={tile.name}
                                                    className="overflow-hidden rounded-xl border border-white/10 bg-[#090b0b]"
                                                >
                                                    <div className="flex aspect-square items-center justify-center bg-white/[0.03] p-3">
                                                        <img
                                                            src={tile.url}
                                                            alt={`Row ${tile.row}, column ${tile.column}`}
                                                            className="max-h-full max-w-full object-contain"
                                                        />
                                                    </div>

                                                    <div className="p-3">
                                                        <p className="truncate text-xs font-semibold text-white/85">
                                                            Row {tile.row} · Column {tile.column}
                                                        </p>

                                                        <p className="mt-1 text-[10px] text-white/40">
                                                            {tile.width} × {tile.height}px
                                                        </p>

                                                        <button
                                                            type="button"
                                                            onClick={() => downloadBlob(tile.blob, tile.name)}
                                                            className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-lg border border-white/10 px-2 py-2 text-xs text-white/75 transition hover:border-white/60 hover:text-white"
                                                        >
                                                            <Download size={14} />
                                                            Download PNG
                                                        </button>
                                                    </div>
                                                </article>
                                            ))}
                                    </div>
                                </div>

                            </div>
                        </section>
                    )}
                </section>

            </div>
        </main>
    );
}

