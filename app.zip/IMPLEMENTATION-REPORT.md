# BROBEX Image Tools — SEO & Technical Upgrade

This update applies the supplied BROBEX website audit to the existing Next.js project. Existing tool workspaces, route structure, brand assets, and theme styling have been retained.

## Implemented

- Updated global and homepage metadata, including page titles, descriptions, keyword targeting, canonical URLs, Open Graph, and Twitter cards.
- Added site-level Organization and WebSite JSON-LD.
- Added homepage WebApplication JSON-LD.
- Added dynamic SoftwareApplication, BreadcrumbList, and HowTo JSON-LD to eligible tool pages; retained FAQPage markup from the existing tool guide component.
- Added CollectionPage and BreadcrumbList JSON-LD to tool category pages.
- Added BROBEX developer authorship and official portfolio attribution.
- Added curated internal links for key image workflows.
- Updated category descriptions for clearer search intent.
- Excluded integration-required placeholder tool pages from the XML sitemap and set their metadata to `noindex,follow` until the integrations are operational.
- Updated robots.txt to advertise the sitemap and disallow API routes.
- Created an optimized WebP logo for page branding and social previews; added explicit logo dimensions to rendered brand images.
- Added and registered practical guides for missing tool pages. All 122 registered tools now have a JSON guide imported and registered.
- Clarified the workspace status label and privacy wording so external-service requirements are not described as a private local-only workflow.

## Validation

- TypeScript/TSX syntax transpilation passed for all changed TypeScript files.
- All 122 tool-guide JSON files parse successfully.
- All 122 tool definitions have a matching guide file, import, and registry entry.
- A full `npm run typecheck` / `npm run build` could not be completed in this environment because dependency installation (`npm ci`) timed out before packages were fully installed. Run both commands locally after extracting the project and installing dependencies.

## Before publishing

1. Run `npm ci`.
2. Run `npm run typecheck` and `npm run build`.
3. Deploy the project.
4. Submit `https://brobeximagetolls.vercel.app/sitemap.xml` in Google Search Console and Bing Webmaster Tools.
5. Verify the site in Search Console and review Core Web Vitals with real-user data.
6. Confirm all integration-required tools remain accurately labeled until their actual providers are configured and tested.
