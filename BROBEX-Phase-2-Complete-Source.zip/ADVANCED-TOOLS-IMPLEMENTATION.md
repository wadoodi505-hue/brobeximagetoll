# BROBEX Image Tools — Phase 2 Implementation Notes

This archive is based on the uploaded BROBEX source project. Existing routes and tool implementations were preserved and extended in place.

## Phase 2 changes

### Image composition and export
- `combine-images` and `add-images-to-image` now use the existing Canvas collage workspace, which supports horizontal, vertical, grid and featured layouts, spacing, margins, background, image fit, and PNG/JPEG/WebP export.
- Added `/tools/overlay-images` with a dedicated two-layer Canvas workspace. It supports opacity, overlay scale, horizontal/vertical placement, background color and PNG/JPEG/WebP export.
- The existing `/tools/image-splitter` already calculates tile bounds from natural image dimensions and exports tiles as a ZIP using the existing JSZip dependency.
- `add-border-to-image` already uses the Canvas image-processing engine; the border is included in the output bitmap, not just CSS.
- The circular profile photo workspace now forces PNG export so the circular mask retains transparent corners.

### Metadata
- Added `lib/image-tools/metadata.ts`.
- JPEG metadata editing writes the standard EXIF ImageDescription, Artist and Copyright fields into a new JPEG APP1 segment. Existing EXIF APP1 segments are replaced; other JPEG segments and scan data are retained.
- For non-JPEG images, the editor exports a JSON sidecar and explicitly does not claim that the image binary was changed.
- Metadata removal decodes and re-encodes the image through Canvas. This removes source metadata from the new output, but browser color management can change pixel encoding.
- `view-metadata` now reads dimensions, file attributes, common JPEG EXIF description/artist/copyright fields, and detects an ICC profile marker. GPS extraction is not implemented.

### Color picker and blemish brush
- The color picker samples a pixel from the natural-size Canvas image data and can export collected colors as CSS variables, JSON or TXT.
- The blemish workspace now applies a basic clone-stamp patch at the selected location. It is not AI content-aware healing and does not promise professional retouching.

### Print sizing and file safety
- A4 sizing uses the physical 210 × 297 mm dimensions at the selected 150 or 300 DPI.
- Advanced image uploads are checked against raster magic-byte signatures, 30 MB file-size and 50-megapixel limits before processing.
- Export filenames are sanitized.
- The overlay workspace limits image inputs to 20 MB and 30 megapixels and releases replaced/unmounted ImageBitmaps.

### Object URL lifecycle
- The shared `ImageWorkspace` already revokes preview and result object URLs on replacement/unmount.
- Added active preview/result URL tracking and cleanup to the OpenCV object-removal and photo-cleanup workspaces.
- Advanced tools revoke prior preview URLs on replacement and unmount.

### Visio formats
- The VSD/VSDX routes are now marked integration-required. No DOCX, PPTX, PDF or JPG conversion download is fabricated.
- VSDX inspection checks the ZIP signature, size and entry count, then extracts page text and embedded media on a best-effort basis.
- Legacy `.vsd` is rejected with a clear instruction to save as `.vsdx` in Microsoft Visio.
- The UI offers only extracted TXT text from a VSDX inspection. Faithful Visio conversion still requires a dedicated Visio-compatible server engine.

### Routing and directory
- Added the `/tools/overlay-images` registry entry and route.
- Routed the existing combine-image tools to the multi-layout Canvas collage workspace.
- Added working links for previously unlinked audited tools in `lib/image-tool-directory.ts`.
- The existing dynamic tool metadata and SoftwareApplication JSON-LD in the dynamic tool route are retained.

## Key files changed or added

- `components/advanced-image-tools-workspace.tsx`
- `components/overlay-images-workspace.tsx` (new)
- `components/remove-objects-workspace.tsx`
- `components/photo-cleanup-workspace.tsx`
- `lib/image-tools/metadata.ts` (new)
- `lib/image-tools/visio.ts`
- `app/tools/[slug]/page.tsx`
- `lib/tools.ts`
- `lib/image-tool-directory.ts`
- `app/globals.css`

No new npm dependency was added; JSZip was already in the supplied project.

## Verification status

The ZIP archive integrity is checked after packaging. A complete `npm ci`, TypeScript check, ESLint run and Next.js production build still need to be run in an environment with dependencies installed. Do not treat this note as a claim that the production build has passed.
