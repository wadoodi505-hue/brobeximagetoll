"use client";

import { useCallback, useEffect, useRef, useState, type PointerEvent } from "react";
import { Download, Eraser, RotateCcw, PenLine, Type, ShieldCheck } from "lucide-react";

type Mode = "draw" | "type";
type ExportFormat = "png" | "jpg";
const CANVAS_WIDTH = 1600;
const CANVAS_HEIGHT = 560;
const MAX_HISTORY = 20;

export function SignatureGeneratorWorkspace() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawingRef = useRef(false);
  const historyRef = useRef<ImageData[]>([]);
  const [mode, setMode] = useState<Mode>("draw");
  const [signature, setSignature] = useState("");
  const [font, setFont] = useState("cursive");
  const [ink, setInk] = useState("#111111");
  const [stroke, setStroke] = useState(5);
  const [format, setFormat] = useState<ExportFormat>("png");
  const [transparent, setTransparent] = useState(true);
  const [hasInk, setHasInk] = useState(false);
  const [historyCount, setHistoryCount] = useState(0);
  const [message, setMessage] = useState("");

  const getContext = useCallback(() => {
    const canvas = canvasRef.current;
    return canvas ? canvas.getContext("2d", { willReadFrequently: true }) : null;
  }, []);

  const paintTypedSignature = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = getContext();
    if (!canvas || !ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!signature.trim()) {
      setHasInk(false);
      return;
    }
    const families: Record<string, string> = {
      cursive: '"Brush Script MT", "Segoe Script", cursive',
      elegant: '"URW Chancery L", "Apple Chancery", cursive',
      serif: 'Georgia, "Times New Roman", serif',
      clean: '"Trebuchet MS", Arial, sans-serif',
    };
    ctx.fillStyle = ink;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.font = `italic 118px ${families[font] ?? families.cursive}`;
    let fitted = 118;
    while (ctx.measureText(signature).width > canvas.width - 120 && fitted > 32) {
      fitted -= 4;
      ctx.font = `italic ${fitted}px ${families[font] ?? families.cursive}`;
    }
    ctx.fillText(signature, canvas.width / 2, canvas.height / 2);
    setHasInk(true);
    historyRef.current = [];
    setHistoryCount(0);
  }, [font, getContext, ink, signature]);

  useEffect(() => {
    if (mode === "type") paintTypedSignature();
  }, [mode, paintTypedSignature]);

  const pointFromEvent = (event: PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((event.clientX - rect.left) / rect.width) * canvas.width,
      y: ((event.clientY - rect.top) / rect.height) * canvas.height,
    };
  };

  const startDrawing = (event: PointerEvent<HTMLCanvasElement>) => {
    if (mode !== "draw") return;
    const canvas = canvasRef.current;
    const ctx = getContext();
    if (!canvas || !ctx) return;
    event.preventDefault();
    canvas.setPointerCapture(event.pointerId);
    const snapshot = ctx.getImageData(0, 0, canvas.width, canvas.height);
    historyRef.current = [...historyRef.current.slice(-(MAX_HISTORY - 1)), snapshot];
    setHistoryCount(historyRef.current.length);
    drawingRef.current = true;
    const point = pointFromEvent(event);
    ctx.beginPath();
    ctx.moveTo(point.x, point.y);
    ctx.lineTo(point.x + 0.1, point.y + 0.1);
    ctx.strokeStyle = ink;
    ctx.lineWidth = stroke;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
    setHasInk(true);
  };

  const continueDrawing = (event: PointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current || mode !== "draw") return;
    const ctx = getContext();
    if (!ctx) return;
    event.preventDefault();
    const point = pointFromEvent(event);
    ctx.lineTo(point.x, point.y);
    ctx.strokeStyle = ink;
    ctx.lineWidth = stroke;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
  };

  const stopDrawing = () => {
    drawingRef.current = false;
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = getContext();
    if (!canvas || !ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    historyRef.current = [];
    setHistoryCount(0);
    setHasInk(false);
    setMessage("Signature canvas cleared.");
  };

  const undo = () => {
    const canvas = canvasRef.current;
    const ctx = getContext();
    const previous = historyRef.current.pop();
    if (!canvas || !ctx || !previous) return;
    ctx.putImageData(previous, 0, 0);
    setHistoryCount(historyRef.current.length);
    const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
    let visible = false;
    for (let i = 3; i < pixels.length; i += 4) {
      if (pixels[i] > 0) { visible = true; break; }
    }
    setHasInk(visible);
  };

  const exportSignature = () => {
    const canvas = canvasRef.current;
    if (!canvas || !hasInk) {
      setMessage("Create a signature before downloading.");
      return;
    }
    const output = document.createElement("canvas");
    output.width = CANVAS_WIDTH;
    output.height = CANVAS_HEIGHT;
    const ctx = output.getContext("2d");
    if (!ctx) {
      setMessage("Your browser could not prepare the export. Please try again.");
      return;
    }
    if (format === "jpg" || !transparent) {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, output.width, output.height);
    }
    ctx.drawImage(canvas, 0, 0, output.width, output.height);
    const mime = format === "jpg" ? "image/jpeg" : "image/png";
    output.toBlob((blob) => {
      if (!blob) {
        setMessage("Export failed. Please try another browser.");
        return;
      }
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `brobex-signature.${format}`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      setMessage(`Your ${format.toUpperCase()} signature is ready.`);
    }, mime, format === "jpg" ? 0.96 : undefined);
  };

  return (
    <section className="brobex-signature" aria-label="Signature generator workspace">
      <header className="brobex-signature-head">
        <div>
          <span className="brobex-signature-kicker">BROBEX CREATIVE STUDIO</span>
          <h2>Create Your Digital Signature</h2>
          <p>Draw a natural signature or type your name, then export a clean image.</p>
        </div>
        <span className="brobex-signature-private"><ShieldCheck size={15}/> Private · Runs in your browser</span>
      </header>

      <div className="brobex-signature-layout">
        <div className="brobex-signature-editor">
          <div className="brobex-signature-toolbar" role="group" aria-label="Signature mode">
            <button type="button" className={mode === "draw" ? "is-active" : ""} onClick={() => { if (mode !== "draw") clearCanvas(); setMode("draw"); setMessage(""); }}><PenLine size={16}/> Draw signature</button>
            <button type="button" className={mode === "type" ? "is-active" : ""} onClick={() => { setMode("type"); setMessage(""); }}><Type size={16}/> Type signature</button>
            <span className="brobex-signature-canvas-label">1600 × 560 px canvas</span>
          </div>

          {mode === "type" && (
            <div className="brobex-signature-typed-controls">
              <label>Full name or signature text<input value={signature} onChange={(event) => setSignature(event.target.value.slice(0, 48))} maxLength={48} placeholder="Type your name" /></label>
              <label>Style<select value={font} onChange={(event) => setFont(event.target.value)}><option value="cursive">Classic cursive</option><option value="elegant">Elegant script</option><option value="serif">Formal serif</option><option value="clean">Modern clean</option></select></label>
            </div>
          )}

          <div className={`brobex-signature-paper ${transparent ? "is-transparent" : "is-white"}`}>
            <canvas ref={canvasRef} width={CANVAS_WIDTH} height={CANVAS_HEIGHT}
              aria-label={mode === "draw" ? "Draw your signature here" : "Typed signature preview"}
              onPointerDown={startDrawing} onPointerMove={continueDrawing}
              onPointerUp={stopDrawing} onPointerCancel={stopDrawing} onPointerLeave={stopDrawing}
              style={{ touchAction: mode === "draw" ? "none" : "auto", cursor: mode === "draw" ? "crosshair" : "default" }} />
            {!hasInk && mode === "draw" && <span className="brobex-signature-placeholder">Sign here using your mouse, stylus or finger</span>}
            {!hasInk && mode === "type" && <span className="brobex-signature-placeholder">Your typed signature preview will appear here</span>}
          </div>

          <div className="brobex-signature-actions">
            <button type="button" onClick={undo} disabled={mode !== "draw" || historyCount === 0}><RotateCcw size={15}/> Undo</button>
            <button type="button" onClick={clearCanvas}><Eraser size={15}/> Clear canvas</button>
            <span>{mode === "draw" ? "Use a steady stroke for a smoother result." : "Choose a style and enter your name above."}</span>
          </div>
        </div>

        <aside className="brobex-signature-settings">
          <h3>Signature settings</h3>
          {mode === "draw" && <label>Pen thickness <output>{stroke}px</output><input type="range" min="1" max="18" value={stroke} onChange={(event) => setStroke(Number(event.target.value))}/></label>}
          <label>Ink color <input type="color" value={ink} onChange={(event) => { setInk(event.target.value); if (mode === "type") paintTypedSignature(); }}/></label>
          <label className="brobex-signature-check"><input type="checkbox" checked={transparent} onChange={(event) => setTransparent(event.target.checked)}/> Transparent background</label>
          <label>Download format<select value={format} onChange={(event) => setFormat(event.target.value as ExportFormat)}><option value="png">PNG · Supports transparency</option><option value="jpg">JPEG · White background</option></select></label>
          <div className="brobex-signature-note"><strong>Export quality</strong><span>High-resolution 1600 × 560 px image. PNG preserves transparent pixels.</span></div>
          <button type="button" className="brobex-signature-download" onClick={exportSignature} disabled={!hasInk}><Download size={17}/> Download signature</button>
          <button type="button" className="brobex-signature-reset" onClick={() => { clearCanvas(); setSignature(""); setInk("#111111"); setStroke(5); setMode("draw"); setTransparent(true); setFormat("png"); }}>Reset settings</button>
          {message && <p className="brobex-signature-message" role="status">{message}</p>}
          <p className="brobex-signature-footnote">Your signature is rendered locally. No paid API, account, or server upload is required. A generated image is not a verified electronic-signature certificate.</p>
        </aside>
      </div>
    </section>
  );
}
