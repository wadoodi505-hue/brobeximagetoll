# Implemented tools and availability

The catalog contains **85 tool routes**: **48 currently marked browser-available** and **37 marked integration-required**. Catalog status describes the implementation path in source; it is not a substitute for a fresh end-to-end QA run on every browser/device.

## Browser workspaces

- **Remove Background from Image** (`/tools/remove-background-from-image`) — AI provider / OCR integration.
- **Upscale Image** (`/tools/upscale-image`) — Local browser canvas resampling.
- **Adjust Photo** (`/tools/colorize-photo`) — Local browser Canvas processing.
- **Make Background Transparent** (`/tools/make-background-transparent`) — Local AI background segmentation using BROBEX engine.
- **Blur Background** (`/tools/blur-background`) — Local AI subject segmentation and canvas background blur.
- **Blur Any Object** (`/tools/blur-any-object`) — Local canvas brush-based selective blur and erasing.
- **Translate Image** (`/tools/translate-image`) — Tesseract.js browser OCR + MyMemory free translation service.
- **Image to Text** (`/tools/image-to-text`) — Local browser OCR with open-source Tesseract.js.
- **TIFF to Text** (`/tools/tiff-to-text`) — UTIF2 TIFF decoder + local Tesseract.js OCR.
- **Resize Image Dimensions** (`/tools/resize-image-dimensions`) — Canvas API.
- **Compress Image Size** (`/tools/compress-image-size`) — Canvas API.
- **Crop Image** (`/tools/crop-image`) — Canvas API.
- **Square Crop** (`/tools/square-crop`) — Canvas API.
- **Triangle Crop** (`/tools/triangle-crop`) — Canvas API.
- **Shape Crop** (`/tools/shape-crop`) — Canvas API.
- **Aspect Ratio Crop** (`/tools/aspect-ratio-crop`) — Canvas API.
- **Black & White** (`/tools/black-white`) — Canvas API.
- **Pixelate Image** (`/tools/pixelate-image`) — Canvas API.
- **Add Text to an Image** (`/tools/add-text-to-image`) — Canvas API.
- **Add Border to Image** (`/tools/add-border-to-image`) — Canvas API.
- **Combine Images** (`/tools/combine-images`) — Canvas API.
- **Add Images to Image** (`/tools/add-images-to-image`) — Canvas API.
- **Make Round Image** (`/tools/make-round-image`) — Canvas API.
- **Profile Photo Maker** (`/tools/profile-photo-maker`) — Canvas API.
- **Image Splitter** (`/tools/image-splitter`) — Browser Canvas API + JSZip.
- **Collage Maker** (`/tools/collage-maker`) — Canvas API.
- **Chart Maker** (`/tools/chart-maker`) — Recharts + Papa Parse + html-to-image + jsPDF.
- **View Metadata** (`/tools/view-metadata`) — Canvas API.
- **Font Awesome to PNG** (`/tools/font-awesome-to-png`) — Font Awesome SVG + Browser Canvas API.
- **PNG to JPG** (`/tools/png-to-jpg`) — Canvas API.
- **JPG to PNG** (`/tools/jpg-to-png`) — Canvas API.
- **PNG to WebP** (`/tools/png-to-webp`) — Canvas API.
- **WebP to PNG** (`/tools/webp-to-png`) — Canvas API.
- **JPG to WebP** (`/tools/jpg-to-webp`) — Canvas API.
- **WebP to JPG** (`/tools/webp-to-jpg`) — Canvas API.
- **PNG to SVG** (`/tools/png-to-svg`) — Browser-based SVG export.
- **SVG to PNG** (`/tools/svg-to-png`) — Canvas API.
- **JPG to AVIF** (`/tools/jpg-to-avif`) — Canvas API.
- **PNG to AVIF** (`/tools/png-to-avif`) — Canvas API.
- **WebP to AVIF** (`/tools/webp-to-avif`) — Canvas API.
- **Merge PDF** (`/tools/merge-pdf`) — pdf-lib (browser).
- **Split PDF** (`/tools/split-pdf`) — pdf-lib (browser).
- **JPG to PDF** (`/tools/jpg-to-pdf`) — pdf-lib (browser).
- **Content Improver** (`/tools/content-improver`) — Offline text helper (template-based; not AI).
- **Essay Writer** (`/tools/essay-writer`) — Offline text helper (template-based; not AI).
- **Paragraph Writer** (`/tools/paragraph-writer`) — Offline text helper (template-based; not AI).
- **Paragraph Completer** (`/tools/paragraph-completer`) — Offline text helper (template-based; not AI).
- **Passport Photo Maker** (`/tools/passport-photo-maker`) — Browser Canvas API.

## Requires an integration or specialist engine

- **JPG to SVG** (`/tools/jpg-to-svg`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **HEIC to JPG** (`/tools/heic-to-jpg`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **HEIC to PNG** (`/tools/heic-to-png`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **HEIC to AVIF** (`/tools/heic-to-avif`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **TIFF to JPG** (`/tools/tiff-to-jpg`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **TIFF to PNG** (`/tools/tiff-to-png`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **TIFF to SVG** (`/tools/tiff-to-svg`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **JPG to TIFF** (`/tools/jpg-to-tiff`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **PNG to TIFF** (`/tools/png-to-tiff`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **GIF to JPG** (`/tools/gif-to-jpg`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **GIF to PNG** (`/tools/gif-to-png`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **GIF to WebP** (`/tools/gif-to-webp`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **GIF to AVIF** (`/tools/gif-to-avif`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **GIF to APNG** (`/tools/gif-to-apng`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **WebP to GIF** (`/tools/webp-to-gif`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **EPS to PNG** (`/tools/eps-to-png`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **EPS to JPG** (`/tools/eps-to-jpg`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **EPS to SVG** (`/tools/eps-to-svg`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **PNG to EPS** (`/tools/png-to-eps`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **PSD to JPG** (`/tools/psd-to-jpg`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **PSD to PNG** (`/tools/psd-to-png`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **PSD to SVG** (`/tools/psd-to-svg`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **PSD to AI** (`/tools/psd-to-ai`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **PDF to JPG** (`/tools/pdf-to-jpg`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **Compress PDF** (`/tools/compress-pdf`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **Edit PDF** (`/tools/edit-pdf`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **PDF to Word** (`/tools/pdf-to-word`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **GIF to MP4** (`/tools/gif-to-mp4`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **VSD to PDF** (`/tools/vsd-to-pdf`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **VSD to DOCX** (`/tools/vsd-to-docx`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **VSD to PPTX** (`/tools/vsd-to-pptx`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **VSD to JPG** (`/tools/vsd-to-jpg`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **VSDX to PDF** (`/tools/vsdx-to-pdf`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **VSDX to DOCX** (`/tools/vsdx-to-docx`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **VSDX to PPTX** (`/tools/vsdx-to-pptx`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **VSDX to JPG** (`/tools/vsdx-to-jpg`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.
- **General File Converter** (`/tools/general-file-converter`) — not marked as working; a suitable decoder, encoder, model, or document engine is not configured in this project.

## Important qualification

- The Upscale Image workspace uses Canvas resampling. It is not AI super-resolution and cannot restore details absent from the source.
- Adjust Photo is a manual browser image-adjustment workspace; it is not a neural photo-colorization model.
- Background segmentation and object/photo tools use dedicated workspaces and may download model assets on demand. Their performance depends on browser memory and device capability.
- Translation uses browser OCR plus a free translation endpoint; translation requires an internet connection and the external service has its own availability and privacy terms.
- Image formats exposed by the catalog are not universally decodable by all browsers. The actual decoder and Canvas encoder must support the selected file and output format.
- Browser availability in the catalog does not mean every feature has been independently regression-tested on every browser. See `TEST-REPORT.md`.
