# BROBEX Image Tools

BROBEX Image Tools is an existing Next.js App Router application for browser-first image utilities. It preserves the original routes and branding while keeping processing on the visitor's device wherever the browser can perform the operation reliably.

## Requirements

- Node.js 20.9 or newer (Node.js 22 LTS recommended)
- npm

## Install and run

```powershell
npm ci
Copy-Item .env.example .env.local
npm run dev
```

Open <http://localhost:3000>.

## Validation

```powershell
npm run typecheck
npm run lint
npm run build
```

Run the checks from the project root. A successful development-server start alone is not a production-build verification.

## Architecture

- Next.js App Router provides the home page, category pages, tool routes, metadata, sitemap, and legal pages.
- `lib/tools.ts` is the canonical tool catalog.
- `components/image-workspace.tsx` is the shared Canvas workspace for the general-purpose image operations.
- `lib/image/process.ts` contains browser-side image decoding, Canvas processing, encoding, and multi-image composition.
- Dedicated workspaces remain in place for passport photos, OCR, translation, TIFF OCR, PDF operations, image splitting, chart creation, photo cleanup, object removal, colorization, and upscaling.
- Browser-side processing avoids uploading the source image to BROBEX servers. Some specialist tools load open-source models or language data when the user starts that operation; first-time downloads and device memory requirements may apply.

## Supported browser operations

The shared Canvas engine currently implements resize, compression, crop, square/triangle/hexagon crop, flip, grayscale, pixelation, text overlay, border, image combination, circular crop, metadata inspection, blur, rotation, supported raster conversion, and browser-side sharpening. Export formats depend on the browser's Canvas encoder support.

PDF merge, page-range split, and image-to-PDF use the bundled `pdf-lib` dependency. OCR uses Tesseract.js and may download language data. Dedicated workspaces may have different limits and should be tested with representative input files before production deployment.

## Important limitations

- Canvas resizing and sharpening cannot reconstruct details that were never present in the source image. The upscaler in this project is browser resampling, not a learned super-resolution model.
- Browser Canvas does not preserve all source metadata and does not offer a universal DPI metadata writer. Pixel dimensions and print-size calculations are not the same as changing embedded DPI metadata.
- Background removal, object removal, colorization, translation, OCR, and other specialist operations may depend on local model assets, browser capabilities, or an external free service. They are not equivalent in reliability or privacy behavior; read each workspace's notice.
- HEIC, TIFF, PSD, EPS, Visio, animated image, and complex document formats need dedicated decoders/encoders. Do not assume that a file extension is supported just because a file picker accepts it.
- Large images can exhaust browser memory. The shared workspace limits input to 20 MB per image and caps output pixel dimensions; dedicated tools may have their own limits.

## Deployment

1. Commit the complete project to your repository.
2. Import it into Vercel as a Next.js project.
3. Configure only environment variables for integrations you intentionally enable. See `.env.example`.
4. Run the validation commands above before deployment.
5. Test real uploads, outputs, downloads, and mobile layouts on the deployed domain.

No private environment file or API secret should be committed.
