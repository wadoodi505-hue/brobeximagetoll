# Processing architecture

## Application structure

- `app/` contains the Next.js App Router pages, API health endpoint, legal pages, sitemap, robots metadata, and dynamic `/tools/[slug]` route.
- `lib/tools.ts` is the source of truth for tool names, slugs, categories, accepted file types, methods, and availability status.
- `components/tool-studio-brand.tsx` provides the shared BROBEX tool-studio shell.
- `components/image-workspace.tsx` provides the common Canvas workspace for catalog operations represented by `ToolDefinition.operation`.
- `lib/image/process.ts` implements image decoding, Canvas transformations, encoding, byte formatting, and multi-image composition.
- Dedicated workspaces remain for passport/ID photo creation, background removal and blur, OCR, image translation, TIFF OCR, image splitting, upscaling/resampling, manual photo adjustment, PDF manipulation, writing helpers, and other specialized workflows.

## Browser image pipeline

1. A user selects or drops a file into the relevant workspace.
2. The workspace validates basic MIME/type and byte-size constraints. The browser decodes the image locally.
3. Settings are passed to the processing function or dedicated workspace. Canvas operations transform pixels locally on the device.
4. The resulting Blob is previewed through a temporary object URL and exposed as a download.
5. Workspaces revoke object URLs during replacement and component cleanup where implemented.

The shared generic workspace currently enforces a 20 MB per-image limit and supports up to 20 files for the batch/combine flows. The processing engine caps dimensions at 12,000 pixels per side; the workspace's automatic compression path also uses a bounded output pixel budget. Individual dedicated workspaces have their own limits.

## Implemented Canvas operations

Resize, compress, rectangular crop, centered square crop, 16:9 aspect crop, triangle and hexagon masks, flip, grayscale, pixelation, text overlay, border, horizontal/vertical composition, circular crop, metadata inspection, blur, rotation, supported raster conversion, and a simple unsharp-mask enhancement. Browser encoder support determines whether a requested output MIME type is available.

## PDF processing

The PDF workspace uses `pdf-lib` for PDF merge, page-range extraction, and JPG/PNG-to-PDF. These operations run in the browser. PDF rendering to raster, PDF-to-Word reconstruction, compression, and editing are not implemented as complete workflows.

## Specialist processing

- Background segmentation uses a locally executed open-source model implementation. Model assets may need to be fetched on first use; this is not the same as a zero-download feature.
- OCR uses Tesseract.js and language traineddata. OCR accuracy depends on image quality, language selection, and device resources.
- Image translation combines OCR with a free external translation endpoint. The translation stage is network-dependent and sends extracted text to that provider; users should avoid sensitive content unless they accept that provider's terms.
- The Upscale Image tool performs browser resampling. It enlarges pixel dimensions but does not infer new image detail.
- Manual photo adjustment uses Canvas-based pixel operations and does not claim AI reconstruction.

## DPI and print sizing

Pixel dimensions and DPI metadata are separate concepts. Print dimensions are calculated as `pixels ÷ DPI`. The current shared Canvas export does not implement a general-purpose embedded DPI metadata writer. Re-encoding through Canvas may discard source metadata. Do not claim that choosing a DPI value changes actual pixel detail or that a file's embedded DPI has been updated unless a dedicated metadata writer is added and tested.

## Unsupported formats and AI limitations

HEIC, TIFF, PSD, EPS, Visio, animated GIF/WebP/APNG, and advanced document formats require dedicated decoders/encoders. Some catalog items remain integration-required. AI upscaling, robust colorization, object removal/inpainting, and generative image editing require specialist models and are not substituted with decorative CSS or generic Canvas effects.

## Privacy and operational constraints

Browser processing keeps source pixels on the visitor's device unless a feature explicitly invokes a remote service. Model downloads, OCR language files, and translation requests are network operations. Large images can exhaust browser memory; strict limits and graceful errors are required. Never expose provider secrets through `NEXT_PUBLIC_` variables.
