# BROBEX Image Tools — project status

This project update works from the user-provided existing Next.js application. It retains the original App Router structure, tool slugs, main workspaces, processing utilities, dependencies, theme provider, and site branding.

## Current source-level implementation

- The shared Canvas image engine supports resize, compress, crop variants, flip, grayscale, pixelation, text overlay, border, composition, circular crop, metadata inspection, blur, rotation, supported raster conversion, and basic sharpening.
- Dedicated workspaces remain for passport photos, background segmentation, object/area blur, OCR, translation, TIFF OCR, image splitting, manual photo adjustment, browser resampling, PDF operations, and writing utilities.
- The PDF workspace implements merge, page-range extraction, and JPG/PNG-to-PDF with `pdf-lib`.
- The tool catalog is maintained in `lib/tools.ts`; unsupported specialist formats remain integration-required rather than receiving fake success behavior.
- Documentation now distinguishes browser implementations from specialist integrations and explains important limitations.
- Encoding artifacts detected in user-facing text and a README merge conflict were repaired.

## Not represented as completed

- Embedded DPI metadata writing is not implemented as a universal export feature.
- Browser resampling is not AI super-resolution.
- AI object removal/inpainting, robust neural colorization, and other model-based editing are not claimed unless a dedicated model is actually present.
- PDF-to-image, PDF-to-Word, PDF editing/compression, HEIC/PSD/EPS/Visio and many animated-format conversions remain unavailable without specialist codecs or engines.
- Official document photo requirements must be checked against the relevant authority; editable presets are not a compliance guarantee.

## Verification status

Dependency installation timed out twice in the authoring container, leaving no complete `node_modules` toolchain. TypeScript, ESLint, production build, browser responsiveness, and end-to-end processing tests could therefore not be run here. The exact status is documented in `TEST-REPORT.md`. Run all checks on a machine with package-registry access before deployment.
