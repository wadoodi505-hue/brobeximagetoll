# BROBEX Tool Inventory

The canonical tool catalog is `lib/tools.ts`. The current 85 tool entries, their slugs, and their availability classification are documented in [`IMPLEMENTED-TOOLS.md`](./IMPLEMENTED-TOOLS.md).

- Browser-available entries are backed by a browser workspace or a Canvas/PDF operation in the current source.
- Integration-required entries intentionally show an unavailable/integration notice instead of simulating a successful result.
- A catalog availability label is not a substitute for end-to-end QA on all browsers and devices. See [`TEST-REPORT.md`](./TEST-REPORT.md).
