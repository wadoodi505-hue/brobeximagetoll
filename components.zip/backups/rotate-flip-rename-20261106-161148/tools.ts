﻿import type { ToolDefinition, Category } from "@/types/tools";

export const tools: ToolDefinition[] = [
  {
    "slug": "remove-background-from-image",
    "name": "Remove Background from Image",
    "description": "Remove an image background with a configured segmentation provider.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "AI provider / OCR integration",
    "status": "browser"
  },
  {
    slug: "upscale-image",
    name: "Upscale Image",
    description:
      "Increase pixel dimensions by 2Ã—, 3Ã—, or 4Ã— using browser resampling. This enlarges the image but does not recreate missing detail.",
    category: "image",
    icon: "WandSparkles",
    acceptedTypes: ["image/png", "image/jpeg", "image/webp", "image/avif", "image/gif"],
    method: "Local browser canvas resampling",
    status: "browser"
  },
  {
    slug: "colorize-photo",
    name: "Adjust Photo",
    description: "Adjust brightness, exposure, contrast, saturation, temperature, sharpness, and more.",
    category: "image",
    icon: "SlidersHorizontal",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp"],
    method: "Local browser Canvas processing",
    status: "browser"
  },
  {
    "slug": "make-background-transparent",
    "name": "Make Background Transparent",
    "description": "Create transparency using a background segmentation provider.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Local AI background segmentation using BROBEX engine",
    "status": "browser"
  },
  {
    "slug": "blur-background",
    "name": "Blur Background",
    "description": "Create a professional background blur with AI-powered subject isolation and adjustable blur strength.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Local AI subject segmentation and canvas background blur",
    "status": "browser"
  },
  {
    "slug": "blur-any-object",
    "name": "Blur Any Object",
    "description": "Paint over any object or area to apply adjustable blur with a brush and eraser.",
    "category": "image",
    "icon": "Brush",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Local canvas brush-based selective blur and erasing",
    "status": "browser"
  },
  {
    "slug": "translate-image",
    "name": "Translate Image",
    "description": "Detect and translate image text using OCR and translation providers.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Tesseract.js browser OCR + MyMemory free translation service",
    "status": "browser"
  },
  {
    "slug": "image-to-text",
    "name": "Image to Text",
    "description": "Extract editable text from images with free, browser-based OCR powered by Tesseract.js.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Local browser OCR with open-source Tesseract.js",
    "status": "browser"
  },
  {
    "slug": "tiff-to-text",
    "name": "TIFF to Text",
    "description": "Extract editable text from single-page and supported multi-page TIFF documents using local browser OCR.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      ".tif",
      ".tiff",
      "image/tiff"
    ],
    "method": "UTIF2 TIFF decoder + local Tesseract.js OCR",
    "status": "browser"
  },
  {
    "slug": "resize-image-dimensions",
    "name": "Resize Image Dimensions",
    "description": "Change image width and height with optional aspect-ratio locking",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "resize"
  },
  {
    "slug": "compress-image-size",
    "name": "Compress Image Size",
    "description": "Automatically compress images into optimized WebP files with one upload. No settings required.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "compress"
  },
  {
    "slug": "crop-image",
    "name": "Crop Image",
    "description": "Crop an image using coordinates and dimensions",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "crop"
  },
  {
    "slug": "square-crop",
    "name": "Square Crop",
    "description": "Create a centered square crop with transparent-free image output.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": ["image/*"],
    "method": "Canvas API",
    "status": "browser",
    "operation": "square-crop"
  },
  {
    "slug": "triangle-crop",
    "name": "Triangle Crop",
    "description": "Crop an image into a triangle with transparent corners.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": ["image/*"],
    "method": "Canvas API",
    "status": "browser",
    "operation": "triangle-crop"
  },
  {
    "slug": "shape-crop",
    "name": "Shape Crop",
    "description": "Create a hexagon-shaped image crop with transparent corners.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": ["image/*"],
    "method": "Canvas API",
    "status": "browser",
    "operation": "shape-crop"
  },
  {
    "slug": "aspect-ratio-crop",
    "name": "Aspect Ratio Crop",
    "description": "Create a centered 16:9 crop for widescreen layouts.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": ["image/*"],
    "method": "Canvas API",
    "status": "browser",
    "operation": "aspect-ratio-crop"
  },  {
    "slug": "flip-image",
    "name": "Flip Image",
    "description": "Flip horizontally or vertically and rotate raster images",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "flip"
  },
  {
    "slug": "black-white",
    "name": "Black & White",
    "description": "Convert an image to grayscale",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "grayscale"
  },
  {
    "slug": "pixelate-image",
    "name": "Pixelate Image",
    "description": "Create a pixelated effect with an adjustable block size",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "pixelate"
  },
  {
    "slug": "add-text-to-image",
    "name": "Add Text to an Image",
    "description": "Add customizable text to an image",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "text"
  },
  {
    "slug": "add-border-to-image",
    "name": "Add Border to Image",
    "description": "Add a solid border around an image",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "border"
  },
  {
    "slug": "combine-images",
    "name": "Combine Images",
    "description": "Combine multiple images into a vertical composition",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Browser Canvas API (local rendering and export)",
    "status": "browser",
    "operation": "combine"
  },
  {
    "slug": "add-images-to-image",
    "name": "Add Images to Image",
    "description": "Overlay/compose multiple images; current workspace combines uploaded images vertically",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Browser Canvas API (local rendering and export)",
    "status": "browser",
    "operation": "combine"
  },
  {
    "slug": "make-round-image",
    "name": "Make Round Image",
    "description": "Export a circular crop with transparent corners",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "circle"
  },
  {
    "slug": "profile-photo-maker",
    "name": "Profile Photo Maker",
    "description": "Create a circular profile image with transparent corners",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "circle"
  },
  {
    "slug": "image-splitter",
    "name": "Image Splitter",
    "description": "Split images into custom rows and columns, preview tiles, and download individual PNG files or a ZIP archive.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Browser Canvas API + JSZip",
    "status": "browser"
  },
  {
    "slug": "collage-maker",
    "name": "Collage Maker",
    "description": "Create polished photo collages with grid and featured layouts, canvas ratios, spacing, margins, rounded corners, background colors, and high-resolution PNG, JPEG, or WebP export.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Browser Canvas API (local rendering and export)",
    "status": "browser",
    "operation": "combine"
  },
  {
    slug: "signature-generator",
    name: "Signature Generator",
    description: "Create a handwritten-style digital signature by drawing with a mouse, stylus, or finger, or typing your name. Export a high-resolution transparent PNG or JPEG directly in your browser.",
    category: "image",
    icon: "PenLine",
    acceptedTypes: [],
    method: "Local HTML Canvas API (no API key or server upload)",
    status: "browser"
  },
  {
    "slug": "chart-maker",
    "name": "Chart Maker",
    "description": "Create professional bar, line, area, pie, doughnut, scatter and radar charts. Import CSV data, customize designs and export charts as PNG, SVG and PDF.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      ".csv",
      "text/csv"
    ],
    "method": "Recharts + Papa Parse + html-to-image + jsPDF",
    "status": "browser"
  },
  {
    "slug": "view-metadata",
    "name": "View Metadata",
    "description": "Inspect image dimensions, MIME type, size, and browser-exposed properties",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/*"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "metadata"
  },
  {
    "slug": "font-awesome-to-png",
    "name": "Font Awesome to PNG",
    "description": "Browse, customize and export Font Awesome solid, regular and brand icons as PNG images.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": ["image/*"],
    "method": "Font Awesome SVG + Browser Canvas API",
    "status": "browser"
  },
  {
    "slug": "png-to-jpg",
    "name": "PNG to JPG",
    "description": "Convert PNG files to JPEG where supported by this browser.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/png"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "convert",
    "outputMime": "image/jpeg",
    "outputExtension": "jpg"
  },
  {
    "slug": "jpg-to-png",
    "name": "JPG to PNG",
    "description": "Convert JPEG files to PNG where supported by this browser.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/jpeg"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "convert",
    "outputMime": "image/png",
    "outputExtension": "png"
  },
  {
    "slug": "png-to-webp",
    "name": "PNG to WebP",
    "description": "Convert PNG files to WEBP where supported by this browser.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/png"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "convert",
    "outputMime": "image/webp",
    "outputExtension": "webp"
  },
  {
    "slug": "webp-to-png",
    "name": "WebP to PNG",
    "description": "Convert WEBP files to PNG where supported by this browser.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/webp"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "convert",
    "outputMime": "image/png",
    "outputExtension": "png"
  },
  {
    "slug": "jpg-to-webp",
    "name": "JPG to WebP",
    "description": "Convert JPEG files to WEBP where supported by this browser.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/jpeg"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "convert",
    "outputMime": "image/webp",
    "outputExtension": "webp"
  },
  {
    "slug": "webp-to-jpg",
    "name": "WebP to JPG",
    "description": "Convert WEBP files to JPEG where supported by this browser.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/webp"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "convert",
    "outputMime": "image/jpeg",
    "outputExtension": "jpg"
  },
  {
    slug: "png-to-svg",
    name: "PNG to SVG",
    description: "Convert PNG images into downloadable SVG files while preserving their original appearance and transparency.",
    category: "image",
    icon: "WandSparkles",
    acceptedTypes: ["image/png"],
    method: "Browser-based SVG export",
    status: "browser",
    operation: "png-to-svg",
    outputMime: "image/svg+xml",
    outputExtension: "svg"
  },
  {
    "slug": "jpg-to-svg",
    "name": "JPG to SVG",
    "description": "Convert JPEG files to SVG+XML where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/jpeg"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/svg+xml",
    "outputExtension": "svg"
  },
  {
    "slug": "svg-to-png",
    "name": "SVG to PNG",
    "description": "Convert SVG+XML files to PNG where supported by this browser.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/svg+xml"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "convert",
    "outputMime": "image/png",
    "outputExtension": "png"
  },
  {
    "slug": "heic-to-jpg",
    "name": "HEIC to JPG",
    "description": "Convert HEIC files to JPEG where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/heic"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/jpeg",
    "outputExtension": "jpg"
  },
  {
    "slug": "heic-to-png",
    "name": "HEIC to PNG",
    "description": "Convert HEIC files to PNG where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/heic"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/png",
    "outputExtension": "png"
  },
  {
    "slug": "heic-to-avif",
    "name": "HEIC to AVIF",
    "description": "Convert HEIC files to AVIF where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/heic"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/avif",
    "outputExtension": "avif"
  },
  {
    "slug": "tiff-to-jpg",
    "name": "TIFF to JPG",
    "description": "Convert TIFF files to JPEG where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/tiff"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/jpeg",
    "outputExtension": "jpg"
  },
  {
    "slug": "tiff-to-png",
    "name": "TIFF to PNG",
    "description": "Convert TIFF files to PNG where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/tiff"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/png",
    "outputExtension": "png"
  },
  {
    "slug": "tiff-to-svg",
    "name": "TIFF to SVG",
    "description": "Convert TIFF files to SVG+XML where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/tiff"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/svg+xml",
    "outputExtension": "svg"
  },
  {
    "slug": "jpg-to-tiff",
    "name": "JPG to TIFF",
    "description": "Convert JPEG files to TIFF where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/jpeg"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/tiff",
    "outputExtension": "tiff"
  },
  {
    "slug": "png-to-tiff",
    "name": "PNG to TIFF",
    "description": "Convert PNG files to TIFF where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/png"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/tiff",
    "outputExtension": "tiff"
  },
  {
    "slug": "jpg-to-avif",
    "name": "JPG to AVIF",
    "description": "Convert JPEG files to AVIF where supported by this browser.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/jpeg"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "convert",
    "outputMime": "image/avif",
    "outputExtension": "avif"
  },
  {
    "slug": "png-to-avif",
    "name": "PNG to AVIF",
    "description": "Convert PNG files to AVIF where supported by this browser.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/png"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "convert",
    "outputMime": "image/avif",
    "outputExtension": "avif"
  },
  {
    "slug": "webp-to-avif",
    "name": "WebP to AVIF",
    "description": "Convert WEBP files to AVIF where supported by this browser.",
    "category": "image",
    "icon": "Image",
    "acceptedTypes": [
      "image/webp"
    ],
    "method": "Canvas API",
    "status": "browser",
    "operation": "convert",
    "outputMime": "image/avif",
    "outputExtension": "avif"
  },
  {
    "slug": "gif-to-jpg",
    "name": "GIF to JPG",
    "description": "Convert GIF files to JPEG where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/gif"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/jpeg",
    "outputExtension": "jpg"
  },
  {
    "slug": "gif-to-png",
    "name": "GIF to PNG",
    "description": "Convert GIF files to PNG where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/gif"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/png",
    "outputExtension": "png"
  },
  {
    "slug": "gif-to-webp",
    "name": "GIF to WebP",
    "description": "Convert GIF files to WEBP where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/gif"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/webp",
    "outputExtension": "webp"
  },
  {
    "slug": "gif-to-avif",
    "name": "GIF to AVIF",
    "description": "Convert GIF files to AVIF where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/gif"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/avif",
    "outputExtension": "avif"
  },
  {
    "slug": "gif-to-apng",
    "name": "GIF to APNG",
    "description": "Convert GIF files to APNG where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/gif"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/apng",
    "outputExtension": "apng"
  },
  {
    "slug": "webp-to-gif",
    "name": "WebP to GIF",
    "description": "Convert WEBP files to GIF where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/webp"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/gif",
    "outputExtension": "gif"
  },
  {
    "slug": "eps-to-png",
    "name": "EPS to PNG",
    "description": "Convert APPLICATION/POSTSCRIPT files to PNG where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "application/postscript"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/png",
    "outputExtension": "png"
  },
  {
    "slug": "eps-to-jpg",
    "name": "EPS to JPG",
    "description": "Convert APPLICATION/POSTSCRIPT files to JPEG where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "application/postscript"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/jpeg",
    "outputExtension": "jpg"
  },
  {
    "slug": "eps-to-svg",
    "name": "EPS to SVG",
    "description": "Convert APPLICATION/POSTSCRIPT files to SVG+XML where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "application/postscript"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/svg+xml",
    "outputExtension": "svg"
  },
  {
    "slug": "png-to-eps",
    "name": "PNG to EPS",
    "description": "Convert PNG files to APPLICATION/POSTSCRIPT where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/png"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "application/postscript",
    "outputExtension": "eps"
  },
  {
    "slug": "psd-to-jpg",
    "name": "PSD to JPG",
    "description": "Convert VND.ADOBE.PHOTOSHOP files to JPEG where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/vnd.adobe.photoshop"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/jpeg",
    "outputExtension": "jpg"
  },
  {
    "slug": "psd-to-png",
    "name": "PSD to PNG",
    "description": "Convert VND.ADOBE.PHOTOSHOP files to PNG where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/vnd.adobe.photoshop"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/png",
    "outputExtension": "png"
  },
  {
    "slug": "psd-to-svg",
    "name": "PSD to SVG",
    "description": "Convert VND.ADOBE.PHOTOSHOP files to SVG+XML where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/vnd.adobe.photoshop"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "image/svg+xml",
    "outputExtension": "svg"
  },
  {
    "slug": "psd-to-ai",
    "name": "PSD to AI",
    "description": "Convert VND.ADOBE.PHOTOSHOP files to APPLICATION/POSTSCRIPT where supported by this browser.",
    "category": "image",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/vnd.adobe.photoshop"
    ],
    "method": "Specialist codec / vectorization integration",
    "status": "integration",
    "outputMime": "application/postscript",
    "outputExtension": "ai"
  },
  {
    "slug": "pdf-to-jpg",
    "name": "PDF to JPG",
    "description": "Convert PDF pages to JPG images using a PDF renderer.",
    "category": "pdf",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "application/pdf",
      "image/jpeg"
    ],
    "method": "PDF library / document conversion integration",
    "status": "integration"
  },
  {
    "slug": "merge-pdf",
    "name": "Merge PDF",
    "description": "Combine multiple PDF files using a PDF processing library.",
    "category": "pdf",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "application/pdf"
    ],
    "method": "pdf-lib (browser)",
    "status": "browser"
  },
  {
    "slug": "split-pdf",
    "name": "Split PDF",
    "description": "Extract selected PDF pages into a new file.",
    "category": "pdf",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "application/pdf"
    ],
    "method": "pdf-lib (browser)",
    "status": "browser"
  },
  {
    "slug": "compress-pdf",
    "name": "Compress PDF",
    "description": "Optimize a PDF with a compatible server-side or browser PDF pipeline.",
    "category": "pdf",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "application/pdf",
      "image/jpeg"
    ],
    "method": "PDF library / document conversion integration",
    "status": "integration"
  },
  {
    "slug": "edit-pdf",
    "name": "Edit PDF",
    "description": "Annotate or edit PDF documents with a PDF editor integration.",
    "category": "pdf",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "application/pdf",
      "image/jpeg"
    ],
    "method": "PDF library / document conversion integration",
    "status": "integration"
  },
  {
    "slug": "jpg-to-pdf",
    "name": "JPG to PDF",
    "description": "Create a PDF document from JPG images.",
    "category": "pdf",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/jpeg",
      "image/png"
    ],
    "method": "pdf-lib (browser)",
    "status": "browser"
  },
  {
    "slug": "pdf-to-word",
    "name": "PDF to Word",
    "description": "Convert PDF content into editable DOCX with a document conversion engine.",
    "category": "pdf",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "application/pdf",
      "image/jpeg"
    ],
    "method": "PDF library / document conversion integration",
    "status": "integration"
  },
  {
    "slug": "gif-to-mp4",
    "name": "GIF to MP4",
    "description": "Convert animated GIF to MP4 using an FFmpeg/WASM or server-side media pipeline.",
    "category": "video",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "image/gif",
      "video/*"
    ],
    "method": "FFmpeg/WASM or server-side media integration",
    "status": "integration"
  },
  {
    "slug": "vsd-to-pdf",
    "name": "VSD to PDF",
    "description": "Requires a Visio-compatible conversion engine.",
    "category": "file",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "*/*"
    ],
    "method": "Specialist file conversion integration",
    "status": "integration"
  },
  {
    "slug": "vsd-to-docx",
    "name": "VSD to DOCX",
    "description": "Requires a Visio/document conversion engine.",
    "category": "file",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "*/*"
    ],
    "method": "Specialist file conversion integration",
    "status": "integration"
  },
  {
    "slug": "vsd-to-pptx",
    "name": "VSD to PPTX",
    "description": "Requires a Visio/document conversion engine.",
    "category": "file",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "*/*"
    ],
    "method": "Specialist file conversion integration",
    "status": "integration"
  },
  {
    "slug": "vsd-to-jpg",
    "name": "VSD to JPG",
    "description": "Requires a Visio-compatible renderer.",
    "category": "file",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "*/*"
    ],
    "method": "Specialist file conversion integration",
    "status": "integration"
  },
  {
    "slug": "vsdx-to-pdf",
    "name": "VSDX to PDF",
    "description": "Requires a Visio-compatible conversion engine.",
    "category": "file",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "*/*"
    ],
    "method": "Specialist file conversion integration",
    "status": "integration"
  },
  {
    "slug": "vsdx-to-docx",
    "name": "VSDX to DOCX",
    "description": "Requires a Visio/document conversion engine.",
    "category": "file",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "*/*"
    ],
    "method": "Specialist file conversion integration",
    "status": "integration"
  },
  {
    "slug": "vsdx-to-pptx",
    "name": "VSDX to PPTX",
    "description": "Requires a Visio/document conversion engine.",
    "category": "file",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "*/*"
    ],
    "method": "Specialist file conversion integration",
    "status": "integration"
  },
  {
    "slug": "vsdx-to-jpg",
    "name": "VSDX to JPG",
    "description": "Requires a Visio-compatible renderer.",
    "category": "file",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "*/*"
    ],
    "method": "Specialist file conversion integration",
    "status": "integration"
  },
  {
    "slug": "general-file-converter",
    "name": "General File Converter",
    "description": "Convert between supported file types through a configured conversion engine.",
    "category": "file",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "*/*"
    ],
    "method": "Specialist file conversion integration",
    "status": "integration"
  },
  {
    "slug": "content-improver",
    "name": "Content Improver",
    "description": "Clean up spacing, punctuation, and common readability issues with an offline text helper. This is template-based, not AI.",
    "category": "write",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "text/plain"
    ],
    "method": "Offline text helper (template-based; not AI)",
    "status": "browser"
  },
  {
    "slug": "essay-writer",
    "name": "Essay Writer",
    "description": "Create a structured essay draft from a topic using an offline template. Review and expand the generated outline.",
    "category": "write",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "text/plain"
    ],
    "method": "Offline text helper (template-based; not AI)",
    "status": "browser"
  },
  {
    "slug": "paragraph-writer",
    "name": "Paragraph Writer",
    "description": "Create a starter paragraph from a topic using an offline template.",
    "category": "write",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "text/plain"
    ],
    "method": "Offline text helper (template-based; not AI)",
    "status": "browser"
  },
  {
    "slug": "paragraph-completer",
    "name": "Paragraph Completer",
    "description": "Create a simple continuation suggestion for a paragraph using an offline template.",
    "category": "write",
    "icon": "WandSparkles",
    "acceptedTypes": [
      "text/plain"
    ],
    "method": "Offline text helper (template-based; not AI)",
    "status": "browser"
  },
  {
    "slug": "increase-image-file-size",
    "name": "Increase Image File Size",
    "description": "Increase an image's exported file size using adjustable encoding quality and image scaling.",
    "category": "image",
    "icon": "FileImage",
    "acceptedTypes": [
      "image/jpeg",
      "image/png",
      "image/webp"
    ],
    "method": "Local browser Canvas API",
    "status": "browser"
  },
  {
    "slug": "passport-photo-maker",
    "name": "Passport Photo Maker",
    "description": "Create correctly sized passport and ID photos with adjustable framing and local browser export.",
    "category": "image",
    "icon": "UserRound",
    "acceptedTypes": [
      "image/jpeg",
      "image/png",
      "image/webp"
    ],
    "method": "Browser Canvas API",
    "status": "browser"
  },
  {
    slug: "compress-image-to-5kb",
    name: "Compress to 5KB",
    description: "Compress an image to 5 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-jpeg-to-10kb",
    name: "JPEG to 10KB",
    description: "Compress an image to 10 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-image-to-15kb",
    name: "Compress to 15KB",
    description: "Compress an image to 15 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-image-to-20kb",
    name: "Compress to 20KB",
    description: "Compress an image to 20 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-jpeg-between-20kb-to-50kb",
    name: "Compress 20KBâ€“50KB",
    description: "Compress an image to 50 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-jpeg-to-25kb",
    name: "JPEG to 25KB",
    description: "Compress an image to 25 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-jpeg-to-30kb",
    name: "JPEG to 30KB",
    description: "Compress an image to 30 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-jpeg-to-40kb",
    name: "JPEG to 40KB",
    description: "Compress an image to 40 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-image-to-50kb",
    name: "Compress to 50KB",
    description: "Compress an image to 50 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-image-to-60kb",
    name: "Compress to 60KB",
    description: "Compress an image to 60 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-image-to-70kb",
    name: "Compress to 70KB",
    description: "Compress an image to 70 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-image-to-80kb",
    name: "Compress to 80KB",
    description: "Compress an image to 80 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-image-to-90kb",
    name: "Compress to 90KB",
    description: "Compress an image to 90 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "resize-image-to-50kb",
    name: "Resize to 50KB",
    description: "Compress an image to 50 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-image-to-100kb",
    name: "Compress to 100KB",
    description: "Compress an image to 100 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-jpeg-to-150kb",
    name: "JPEG to 150KB",
    description: "Compress an image to 150 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-image-to-200kb",
    name: "Compress to 200KB",
    description: "Compress an image to 200 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "resize-image-to-200kb",
    name: "Resize to 200KB",
    description: "Compress an image to 200 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-jpeg-to-300kb",
    name: "JPEG to 300KB",
    description: "Compress an image to 300 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-jpeg-to-500kb",
    name: "JPEG to 500KB",
    description: "Compress an image to 500 KB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-image-to-1mb",
    name: "Compress to 1MB",
    description: "Compress an image to 1 MB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  },
  {
    slug: "compress-image-to-2mb",
    name: "Compress to 2MB",
    description: "Compress an image to 2 MB or less while preserving its original pixel dimensions.",
    category: "image",
    icon: "FileImage",
    acceptedTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"],
    method: "Local browser Canvas API with fixed-target JPEG quality search",
    status: "browser"
  }
] as ToolDefinition[];

export const categories: { id: Category; label: string; href: string; description: string }[] = [
  { id: "pdf", label: "PDF", href: "/tools/pdf", description: "Organize, convert, and prepare PDF documents." },
  { id: "image", label: "Image", href: "/tools/image", description: "Edit, optimize, and convert images in your browser." },
  { id: "write", label: "Write", href: "/tools/write", description: "Writing utilities with clear provider setup states." },
  { id: "video", label: "Video", href: "/tools/video", description: "Media conversion tools with documented processing requirements." },
  { id: "file", label: "File", href: "/tools/file_conversion", description: "Convert specialist and general file formats." },
];
export function getTool(slug: string) { return tools.find((tool) => tool.slug === slug); }













