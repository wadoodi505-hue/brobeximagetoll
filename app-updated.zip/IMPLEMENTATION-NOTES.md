# BROBEX Image Tools — implementation update

## Changes included

- Replaced the AdSense component and directory ad placeholder with a branded BROBEX Code YouTube promotion linking to `https://www.youtube.com/@BrobexCode`.
- Removed the AdSense account metadata and remote AdSense script from the application layout.
- Updated Increase Image File Size with a free-form target field accepting values such as `500 KB`, `1 MB`, `1024 KB`, and decimal values, plus a continuous 1-byte-to-50-MB slider and validation.
- Kept the Increase Image File Size heading black for consistent contrast.
- Updated Rotate & Flip Image so an untouched image shows the original; any rotation/flip shows the edited canvas; resetting all edits returns to the original.
- Limited Crop Round Corners to 50% and 100% values and added exactly three visual preset cards.
- Added responsive sticky preview behavior for Aspect Ratio Crop, Circular Profile Photo Maker, Overlay Images, and Combine Multiple Images.
- Added direct pointer/touch positioning to Aspect Ratio Crop, Circular Profile Photo Maker, and Overlay Images.
- Added Fix Screen to Blemishes Remover. It locks document and body scrolling while active and restores the prior overflow settings when disabled or when the workspace unmounts.
- Removed Edit Metadata, Remove Metadata, Square Crop as a standalone tool, and Add Images to Image from the tool registry and guide index; deleted their guide JSON files and removed obsolete metadata-writing/stripping implementations. The 1:1 square crop option remains inside the unified Crop Image workspace as a crop preset, not as a separate tool.
- Moved Crop Image into the Image Editing directory classification.
- Removed two obsolete signature-preset backup directories that still contained the deleted metadata tool entries.

## Validation

- All 77 TypeScript/TSX source files passed TypeScript transpilation syntax checks.
- A full `npm run typecheck` and `npm run build` could not be completed in this environment because `npm ci` could not finish downloading the locked dependencies from the npm registry. Run these commands in the project environment after installing dependencies:

```powershell
npm ci
npm run typecheck
npm run build
```
